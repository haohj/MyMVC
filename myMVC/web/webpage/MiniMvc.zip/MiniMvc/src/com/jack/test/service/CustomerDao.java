package com.jack.test.service;

public interface CustomerDao {
	public void sayHello() ;
}
